﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Lab1_Kristoffer
{
    class Program
    {
        static void Main(string[] args)
        {
            //Uppgift 1
            Random rnd = new Random();
            int[] myArray = new int[rnd.Next(5,30)];
            Console.WriteLine("Uppgift 1: \n");
            ArrayCounter(myArray);
            Console.WriteLine("-----------------------------------------------------------------");

            //Uppgift 2 - Brute Force Array
            int[] arrayA = {7, 4, 9, 2, 6, 1, 3, 9, 2, 10, 8, 2, 3, 5, 1, 8, 8};
            int[] arrayB = {7, 1, 6, 8, 5, 11, 2, 23, 15};
            Console.WriteLine("Uppgift 2 Bruteforce: \n");
            BruteForce(arrayA);
            Console.WriteLine("-----------------------------------------------------------------");

            //Uppgift 2 - Algoritm
            Console.WriteLine("Uppgift 2 Algorithem: \n");
            ArrayDifference(arrayA);
            Console.WriteLine("-----------------------------------------------------------------");            
        }

        private static void ArrayCounter(int[] myArray)
        {
            DateTime startTime = DateTime.Now;
            Random rnd = new Random();
            int number = rnd.Next(5,30);
            // int[] myArray = new int[number];
            Random randNum = new Random();

            //Testing for negative values in the array, this algorithem can not count for negative values.
            // int number = 2;
            // int[] myArray = new int[10];
            
            StringBuilder csv = new StringBuilder();

            //Add random values to the array
            for (int i = 0; i < myArray.Length; i++)
            {
                myArray[i] = randNum.Next(0, 20);  
            }
            
            int count = 0;
            //Loop trough the array and check if the numbers in the array is = to int number
            foreach(var item in myArray)
            {
                //We can add the or statement to check for negative of the same number also
                Console.WriteLine("Nummer i arrayen: "+item);
                if(item == number /*|| item == number*-1*/)
                {
                    count += 1;
                }
            }  
            Console.WriteLine("Talet: "+number+" Förekommer: "+count+" gånger"); 
            DateTime stopTime = DateTime.Now;
            TimeSpan elapsed = stopTime - startTime;
            
            Console.WriteLine("Time: "+elapsed.ToString().Substring(7));


            //To csv        
            string newFileName = "results.csv";
            string csvCount = count.ToString();
            string csvElapsed = elapsed.ToString();
            var csvText = String.Format("{0};{1};",csvElapsed.Substring(7),csvCount);
            csv.Append(csvText);
            if(!File.Exists(newFileName))
            {
                string clientheader = ("Time" + "," + "Count"+Environment.NewLine);
                File.WriteAllText(newFileName, clientheader);
            }
            File.AppendAllText(newFileName, csv.ToString() + Environment.NewLine);
        }

        // private static int BruteForce(int[] arrayA, int[] arrayB)
        // {
        //     DateTime startTime = DateTime.Now;
        //     int bigNumA = 0;
        //     int bigNumB = 0;
        //     foreach(int i in arrayA)
        //     {
        //         foreach(int j in arrayB)
        //         {
        //             int newNum = i - j;
        //             if(newNum > bigNumA)
        //             {
        //                 bigNumA = newNum;
        //             }
        //         }
        //     }
        //     foreach(int i in arrayB)
        //     {
        //         foreach(int j in arrayB)
        //         {
        //             int newNum = i - j;
        //             if(newNum > bigNumB)

        //             {
        //                 bigNumB = newNum;
        //             }
        //         }
        //     }
        //     DateTime stopTime = DateTime.Now;
        //     TimeSpan elapsed = stopTime - startTime;
        //     Console.WriteLine("Time: "+elapsed.ToString().Substring(7)+"\n"+"Resultat Array A: "+bigNumA+"\n"+"Resultat Array B: "+bigNumB);

        //     return bigNumA;
        // }
                private static int BruteForce(int[] arrayA)
        {
            DateTime startTime = DateTime.Now;
            int bigNumA = 0;
            foreach(int i in arrayA)
            {
                foreach(int j in arrayA)
                {
                    int newNum = i - j;
                    if(newNum > bigNumA)
                    {
                        bigNumA = newNum;
                    }
                }
            }

            DateTime stopTime = DateTime.Now;
            TimeSpan elapsed = stopTime - startTime;
            Console.WriteLine("Time: "+elapsed.ToString().Substring(7)+"\n"+"Result: "+bigNumA+"\n");

            return bigNumA;
        }
        private static int ArrayDifference(int[] arrayA)
        {
            DateTime startTime = DateTime.Now;
            int small_num = 0;
            int biggest_num = 0;

            if (arrayA.Length > 0) small_num = biggest_num = arrayA[0];

            for (int i = 1; i < arrayA.Length; i++)
            {
                small_num = Math.Min(small_num, arrayA[i]);
                biggest_num = Math.Max(biggest_num, arrayA[i]);
            }
            int result = biggest_num - small_num;
            DateTime stopTime = DateTime.Now;
            TimeSpan elapsed = stopTime - startTime;
            Console.WriteLine("Time: "+elapsed.ToString().Substring(7)+"\n"+"Result: "+result);
            return result; 
        }
    }
}
